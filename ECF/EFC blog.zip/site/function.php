<?php 
require_once 'dbconnect.php';

function getAllArticles() {
    $pdo = dbconnect();
    $query = "SELECT * FROM article";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $articles;
}

function getAllCategories(){
    $pdo = dbconnect();
    $query = "SELECT * FROM categories";
    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $categories = $stmt->fetchObject(PDO::FETCH_ASSOC);
    return $categories;
}

function calcResume($content, $length = 200){
    $text = strip_tags($content);
    if (strlen($text) <= $length ){
        return $text;
    }
    $preface = substr($text, 0, $length);
    $preface = substr($preface, 0, strrpos($preface,' '));
    return $preface;
}

function getArticleById($id){
    $pdo = dbconnect();
    $query = "SELECT * FROM article WHERE id_article = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $articles = $stmt->fetch(PDO::FETCH_ASSOC);
    return $articles;
}

function getCategoriesById($id){
    $pdo = dbconnect();
    $query = "SELECT * FROM categories WHERE id_categorie = :id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $articles = $stmt->fetch(PDO::FETCH_ASSOC);
    return $articles;
}

function getUserByEmail($email){
    $pdo = dbconnect();
    $query = "SELECT * FROM user WHERE email = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    return $user;
}

function userInsert($pseudo, $email, $password){
    $pdo = dbconnect();
    $query = "INSERT INTO user(pseudo, email, password) VALUES (:pseudo, :email, :password)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':pseudo', $pseudo);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);
    $stmt->execute();
}

function getArticleByCategorie($id_categorie){
    $pdo = dbconnect();
    $query = "SELECT * FROM article
        JOIN categorie_articles ON article.id_article = categorie_articles.article_id 
        WHERE categorie_articles.categorie_id = :id_categorie";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id_categorie', $id_categorie);
    $stmt->execute();
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    return $articles;
}

?>